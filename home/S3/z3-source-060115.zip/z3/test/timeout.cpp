
#include "timeout.h"
#include "trace.h"

#ifdef _WINDOWS

#include "windows.h"

void tst_timeout() {
}

#else
void tst_timeout() {
}

#endif
