Use 'build.cmd' to build the test application using Microsoft C#
compiler.

Remark: The Microsoft C# compiler (csc) must be in your path,
or you can use the Visual Studio Command Prompt.

