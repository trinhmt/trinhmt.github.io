WARNING: this example still uses the old Z3 (version 3.x) C API. The current version is backward compatible. 

This directory contains scripts to build the MaxSAT application using gcc.

Use 'build.sh' to build the MaxSAT application using gcc. 
The script 'exec.sh' adds the lib directory to the path. So, 
maxsat can find libz3.dylib.

