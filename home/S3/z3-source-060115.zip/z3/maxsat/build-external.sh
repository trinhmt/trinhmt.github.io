gcc -o maxsat.exe -I ../../include ../../bin/z3.dll maxsat.c
