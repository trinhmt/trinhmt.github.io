export DYLD_LIBRARY_PATH=../../lib:$DYLD_LIBRARY_PATH
./maxsat $1
