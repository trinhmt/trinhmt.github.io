gcc -fopenmp -o maxsat maxsat.c -I ../../include -L ../../lib -lz3 
