export PATH=../../bin:$PATH
./maxsat.exe $1
