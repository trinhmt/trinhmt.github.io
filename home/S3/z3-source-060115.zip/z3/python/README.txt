To run the test script execute:
python example.py

Learn more about Z3Py at:
http://rise4fun.com/Z3Py/tutorial/guide
