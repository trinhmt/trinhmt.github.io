WARNING: this example still uses the old Z3 (version 3.x) C API. The current version is backward compatible. Please go to the examples/c++ for examples using the new API.  

This directory contains scripts to build the test application using gcc.

Use 'build.sh' to build the test application using gcc. 
The script 'exec.sh' adds the lib directory to the path. So, 
test_capi can find libz3.so.

