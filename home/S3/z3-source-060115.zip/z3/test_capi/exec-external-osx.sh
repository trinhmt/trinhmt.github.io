export DYLD_LIBRARY_PATH=../../lib:$DYLD_LIBRARY_PATH
./test_capi
