gcc -fopenmp -o test_capi.exe -I ../../include ../../bin/z3.dll test_capi.c
