export PATH=../../bin:$PATH
./test_capi.exe
