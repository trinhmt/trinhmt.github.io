g++ -fopenmp -o example -I ../../include example.cpp -L ../../lib -lz3 
